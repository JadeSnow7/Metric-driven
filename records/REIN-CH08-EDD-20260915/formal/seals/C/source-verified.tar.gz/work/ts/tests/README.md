# TypeScript tests

主线的验收测试，输入取自 `fixtures/` 或本地构造的桩，不访问外网。不制造空测试或虚假的通过状态。

第 01 章的用例：

- `config.test.ts`：三个环境变量各自缺失、为空、格式不对时的报错，以及"不静默回退到默认值"这一条本身。
- `chat.test.ts`：成功路径取出文本与 usage；四类失败（网络、非 2xx、超时、响应形状）各自可区分，且错误信息里带有路径与下一步线索。
- `transport.test.ts`：fetch 实现对状态码与响应体的原样搬运、连接失败与超时的映射（只用回环地址上的本地服务）；回放实现的顺序与样本用尽。
- `record.test.ts`：录制命令的参数校验与 provider 名称推导。
- `recorded.test.ts`：`fixtures/responses/` 中两份历史录制的回放，以及样本脱敏检查。

第 03 章接入只读工具的验收（读取成功、文件不存在、参数错误），输入改由 `fixtures/cases/` 提供。
