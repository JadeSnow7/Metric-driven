# 简短示例

## L2：1.3 Spec 绑定记录片段

复杂任务的 1.3 状态把规范索引与运行回执分开：

```json
{
  "schema_version": "1.3",
  "spec": {
    "version": "SPEC-1",
    "authority": "state.spec",
    "source_ids": ["SRC-001"],
    "goal_ref": "discovery.expected_outcome",
    "scope_ref": "discovery.scope",
    "constraints": [], "exceptions": [], "open_items": [],
    "conditions": [{"id": "SC-01", "metric_ids": ["MET-01"], "deliverables": ["docs/result.md"]}],
    "contracts": []
  },
  "binding": {"receipt_paths": ["records/TASK-001/evidence/run.json"]}
}
```

回执内容变化不改变 Spec digest；新增或修改条件、指标规范字段、契约文件字节或交付分类会使当前绑定失效。缺少 1.3 绑定的历史记录保留原样并标为旧语义审计，不能只修改外层版本字段来伪造重跑。

## L0：已定位的小缺陷，直接修并简短汇报

回到 L0 示例时，用户说：“`paginate()` 翻到最后一页时总少一条，`tests/test_paging.py::test_last_page` 挂了，帮我修一下。”

问题、位置和验收（那条失败的用例）都已明确，也没有要求提交，属于轻量任务。先看 `git status`，核实成因（例如用 `total=21, size=10` 手算最后一页的切片范围），修改实现而不是断言，选能区分正确修复的检查点（整除与不整除两种总数），然后按结果、依据和限制的阅读顺序汇报：

> **改法**：`paging.py` 计算总页数时把 `total // size` 改为向上取整，最后一页不再被丢掉。
> **检查**：`pytest tests/test_paging.py -q` → 7 passed（此前 1 failed）；另补测 `total=20, size=10`（整除）仍是 2 页。完整测试集未运行。
> **限制与行为变化**：总数能被页大小整除时结果不变；本次没有改变 `size=0` 的输入契约，专门针对该输入的检查未运行。

不需要建立 `records/`、编号或指标表。如果修复过程中发现需要改接口语义或会影响其他模块，再升级到 L1 并说明原因。

## 模糊请求：先澄清，不生成实现承诺

用户说：“给后台加一个智能搜索，要快一点。”

此时至少缺少使用者、搜索对象、当前问题、可接受结果和数据环境。正确下一步不是先建向量库，而是询问少量会改变方案的问题，例如：主要用户要找什么、现有搜索最常失败在哪里、是否允许外部服务、怎样的响应与结果算可接受。

若用户同意先探索，可建立 `HYP-001`：“混合检索能改善已知失败查询”；预算限定为一份固定查询集与两种实现对比，退出结果只回答是否值得进入产品实现。

## 复杂请求：先按结果拆主任务

用户要求“导入旧系统数据、提供新查询接口、上线后可回滚”。先拆为：

- `MT-001`：用户历史数据可完整、可核对地进入新系统；
- `MT-002`：调用方可通过兼容接口取得正确结果；
- `MT-003`：上线失败时可恢复到已知状态；
- 整体验收：从旧数据样本导入到查询，再执行一次演练回滚。

之后才分别建立完整性门槛、接口兼容门槛和恢复门槛，再拆迁移脚本、接口实现、监控等 `IT-*`。不要把“写数据库脚本 / 写后端 / 写 CI”直接当主任务。

## 恢复任务：先核验副作用

摘要写“已推送”，日志有 `ACT-003` 和远程回执，但本地分支落后。恢复者先核验本地 HEAD、远程分支与回执，再决定拉取或继续；不能因为当前工作区看不到提交就再次推送。

记录里 `ACT-004`（`migrate`，目标 `db:staging`）停在 `in_progress`，说明上次会话可能在迁移途中中断。恢复者先查询 staging 数据库的迁移版本表：已经是目标版本就把动作改为 `completed` 并写入版本号作为回执；仍是旧版本时，继续核对迁移日志、部分写入和仍在运行的进程；确认失败且重试安全后改为 `failed` 并写明核验结果，再运行 `--gate action --action migrate --target db:staging` 后重试。在核验之前，门槛会报 `ACTION_OUTCOME_UNKNOWN` 阻止重做。

如果执行记录内的 revision 与当前内容不同，校验器会报 `EXECUTION_REVISION_STALE`；重跑受影响检查、换上新记录，不能直接从“上次通过”恢复到提交或部署。

## 工作区里有别人的改动

`git status` 显示 `docs/roadmap.md` 有未提交修改，本任务只改 `src/paging.py` 和对应测试。两者不重叠，所以直接在原目录继续：L0/L1 在汇报里说明检查时该文件有他人改动；L2 把它写进 `baseline.foreign_paths`。提交时先 `git add -- src/paging.py tests/test_paging.py`，再 `git commit -m "fix last page" -- src/paging.py tests/test_paging.py`，不把 `docs/roadmap.md` 带进去。只有本任务也要改 `docs/roadmap.md` 时才先问用户。

## 验证环境不可用

性能基准需要的专用机器今天无法访问，功能测试已全部通过，用户说“先提交，基准等机器恢复后在 CI 上跑”。把性能指标记为 `deferred`，`decision_id` 指向记录这句话的 `DEC-*`。可在本地提交门槛通过后提交；推送仍需已有或新增的 `push` 授权。报告把该指标列为“未验证”；在基准结果出来之前，合并门槛会报 `METRIC_DEFERRED_BLOCKS`。用户没有这样决定时，指标保持 `undetermined`，提交门槛照常阻断。
